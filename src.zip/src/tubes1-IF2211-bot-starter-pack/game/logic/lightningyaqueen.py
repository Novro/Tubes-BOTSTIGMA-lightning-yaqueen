from typing import Optional, Tuple, List, Dict
from game.logic.base import BaseLogic
from game.models import GameObject, Board, Position
import heapq


class LightningYaqueen(BaseLogic):
    def __init__(self):
        self.width = 0
        self.height = 0
        self.grid = []

    def build_grid(self, board: Board):
        self.width = board.width
        self.height = board.height
        self.grid = [[0] * self.width for _ in range(self.height)]

    def neighbors(self, pos: Position) -> List[Position]:
        directions = [(1, 0), (-1, 0), (0, 1), (0, -1)]
        result = []
        for dx, dy in directions:
            nx, ny = pos.x + dx, pos.y + dy
            if 0 <= nx < self.width and 0 <= ny < self.height:
                if self.grid[ny][nx] == 0:
                    result.append(Position(ny, nx))
        return result

    def dijkstra(self, start: Position) -> Tuple[Dict[Tuple[int, int], int], Dict[Tuple[int, int], Tuple[int, int]]]:
        dist = {(y, x): float('inf') for y in range(self.height) for x in range(self.width)}
        dist[(start.y, start.x)] = 0
        prev = {}
        heap = [(0, (start.y, start.x))]

        while heap:
            cost, (y, x) = heapq.heappop(heap)
            if cost > dist[(y, x)]:
                continue
            for n in self.neighbors(Position(y, x)):
                nd = (n.y, n.x)
                alt = cost + 1
                if alt < dist[nd]:
                    dist[nd] = alt
                    prev[nd] = (y, x)
                    heapq.heappush(heap, (alt, nd))
        return dist, prev

    def reconstruct_path(self, prev, start: Position, end: Position) -> List[Position]:
        path = []
        current = (end.y, end.x)
        start_pos = (start.y, start.x)
        while current != start_pos:
            path.append(Position(current[0], current[1]))
            current = prev.get(current)
            if current is None:
                return []
        path.reverse()
        return path

    def select_diamonds_knapsack(self, diamonds: List[GameObject], dist: Dict[Tuple[int, int], int],
                                 base_pos: Position, inventory_max: int, exclude_red: bool = False) -> List[GameObject]:
        def total_distance(d: GameObject):
            return dist.get((d.position.y, d.position.x), float('inf')) + abs(d.position.x - base_pos.x) + abs(d.position.y - base_pos.y)

        candidates = []
        for d in diamonds:
            if exclude_red and d.properties.points == 2:
                continue
            dist_total = total_distance(d)
            if dist_total == 0:
                dist_total = 1
            ratio = d.properties.points / dist_total
            candidates.append((ratio, d))

        candidates.sort(key=lambda x: x[0], reverse=True)

        selected = []
        total_items = 0
        for ratio, d in candidates:
            if total_items < inventory_max:
                selected.append(d)
                total_items += 1
            else:
                break

        return selected

    def next_move(self, board_bot: GameObject, board: Board) -> Tuple[int, int]:
        self.build_grid(board)
        current_pos = board_bot.position
        inventory = board_bot.properties.diamonds or 0
        inventory_max = board_bot.properties.inventory_size or 5
        base_pos = board_bot.properties.base

        dist, prev = self.dijkstra(current_pos)

        diamonds = board.diamonds or []
        enemy_bots = [b for b in (board.bots or []) if b.properties.name != board_bot.properties.name]

        # Cek ada musuh di sekitar (jarak 1)
        enemy_nearby = any(dist.get((b.position.y, b.position.x), float('inf')) == 1 for b in enemy_bots)

        # Pilih diamond merah dan biru terpisah
        red_diamonds = [d for d in diamonds if d.properties.points == 2]
        blue_diamonds = [d for d in diamonds if d.properties.points == 1]

        # Hitung jarak ke base
        dist_to_base = dist.get((base_pos.y, base_pos.x), float('inf'))

        # Tentukan target:
        # Jika inventory >=4, abaikan diamond merah dan cari biru
        if inventory >= 4:
            candidate_diamonds = self.select_diamonds_knapsack(blue_diamonds, dist, base_pos, inventory_max - inventory)
        else:
            # Gabung diamond merah + biru untuk knapsack
            candidate_diamonds = self.select_diamonds_knapsack(diamonds, dist, base_pos, inventory_max - inventory)

        # Jika ada musuh dekat dan inventory >0 dan jarak base lebih dekat dari diamond terdekat
        if enemy_nearby and inventory > 0:
            # Cari jarak diamond terdekat
            if candidate_diamonds:
                candidate_diamonds.sort(key=lambda d: dist.get((d.position.y, d.position.x), float('inf')))
                dist_to_nearest_diamond = dist.get((candidate_diamonds[0].position.y, candidate_diamonds[0].position.x), float('inf'))
            else:
                dist_to_nearest_diamond = float('inf')

            if dist_to_base < dist_to_nearest_diamond:
                target = base_pos
            else:
                target = candidate_diamonds[0].position if candidate_diamonds else base_pos
        else:
            # Jika inventory penuh atau hampir penuh dan tidak ada diamond, langsung ke base
            if inventory >= inventory_max or (inventory == inventory_max -1 and not candidate_diamonds):
                target = base_pos
            else:
                target = candidate_diamonds[0].position if candidate_diamonds else base_pos

        path = self.reconstruct_path(prev, current_pos, target)
        if not path:
            return 0, 0

        next_step = path[0]
        dx = next_step.x - current_pos.x
        dy = next_step.y - current_pos.y

        if abs(dx) + abs(dy) != 1:
            return 0, 0
        return dx, dy
